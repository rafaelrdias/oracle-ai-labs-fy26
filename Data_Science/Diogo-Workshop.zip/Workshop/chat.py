from langchain_community.chat_models.oci_generative_ai import ChatOCIGenAI
from langchain_openai import ChatOpenAI
from mcp_use import MCPAgent, MCPClient
import asyncio
from dotenv import load_dotenv

from rich.markdown import Markdown
from rich.console import Console
from rich.live import Live

from dotenv import load_dotenv


load_dotenv()

# COMPARTMENT_ID = "ocid1.compartment.oc1..aaaaaaaalrofzx44ro4tmtbhdbfwnfx2karrdsjwkbscrcltsiidqngeakua"
# llm = ChatOCIGenAI(
#     auth_type='INSTANCE_PRINCIPAL',
#     model_id="cohere.command-r-plus-08-2024",
#     service_endpoint="https://inference.generativeai.sa-saopaulo-1.oci.oraclecloud.com",
#     compartment_id=COMPARTMENT_ID, # os.environ["NB_SESSION_COMPARTMENT_OCID"],
#     model_kwargs={"temperature": 0, "max_tokens": 4_000} 
# )

llm = ChatOpenAI(model="gpt-4.1")

client = MCPClient.from_config_file("mcp_config.json")
agent = MCPAgent(llm=llm, client=client, max_steps=30)


async def main():
    console = Console()
    msgs = []

    while True:
        # Get user input
        user_input = input("\n[You] ")

        if user_input == '':
            continue
        
        # Check if user wants to exit
        if user_input.lower() in ['exit', 'quit', 'bye', 'goodbye']:
            print("Goodbye!")
            break
        
        try:
            # Process the user input and output the response
            print("\n[Assistant]")
            with Live('', console=console, vertical_overflow='visible') as live:
                
                message = await agent.run(user_input, max_steps=30)
                live.update(Markdown(message))
                
                # Add the new messages to the chat history
                # msgs.extend(message)
            
        except Exception as e:
            print(f"\n[Error] An error occurred: {str(e)}")
            break

        # result = await agent.run('How many days between 2000-01-01 and 2025-03-18?')
        
    # print(result.data)
    #> There are 9,208 days between January 1, 2000, and March 18, 2025.

if __name__ == "__main__":
    asyncio.run(main())
